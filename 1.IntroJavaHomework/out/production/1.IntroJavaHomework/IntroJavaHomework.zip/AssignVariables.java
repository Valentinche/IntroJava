public class AssignVariables {
    public static void main(String[] args) {
        byte a = 127;
        short b = 32767;
//    short c=32768; is not valid
        int d = 2000000000;
        long e = 919827112351L;
        char f = 'c';
        boolean g = false;
        float h = 0.5f;
        double i = 0.1234567891011;
        String name = "Palo Alto, CA";
        System.out.println(a+"\n"+b+"\n"+d+"\n"+e+"\n"+f+"\n"+g+"\n"+h+"\n"+i+"\n"+name);

    }
}
