
public class PrintCharacters {
    public static void main(String[] args) {
        for (char c = 'a'; c <=122 ; c++) {
            System.out.print(c+" ");

        }
    }
}
